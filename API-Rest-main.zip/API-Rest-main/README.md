# Proyecto-API-Rest
## Descripción
Este repositorio contiene el trabajo práctico de API Rest con Spring Boot
## Contenido del Repositorio
- Carpeta llamada restinicial-inicial1 donde se encuentra todo el codigo disponible
## Características de Ejecución
Para visualizar el trabajo práctico:

1. **Clonar el Repositorio**:
   https://github.com/LisanMonclus/API-Rest
